import {
  useMemo,
  useState,
} from 'react';

import type {
  Deal,
} from './types';

type DealViewMode =
  | 'cards'
  | 'expanded';

type LooseTask = {
  id: string;
  title?: string;
  type?: string;
  status?: string;
  urgent?: boolean;
};

type LooseInvoice = {
  id?: string;
  sellerType?: 'ST' | 'MSM' | 'IP';
  number?: string;
  invoiceNumber?: string;
  amount?: number | string;
  invoiceDate?: string;
  createdAt?: string;
  isCurrent?: boolean;
  status?: string;
};

function money(
  value: unknown,
) {
  const normalized =
    typeof value === 'number'
      ? value
      : Number(
          String(value ?? '')
            .replace(/\s/g, '')
            .replace(',', '.')
        );

  if (!Number.isFinite(normalized)) {
    return '—';
  }

  return new Intl.NumberFormat(
    'ru-RU',
    {
      maximumFractionDigits: 2,
    },
  ).format(normalized) + ' ₽';
}

function shortDate(
  value: unknown,
) {
  if (!value) {
    return '—';
  }

  const date =
    new Date(String(value));

  if (
    Number.isNaN(date.getTime())
  ) {
    return '—';
  }

  return date.toLocaleDateString(
    'ru-RU',
  );
}

function taskLabel(
  task: LooseTask,
) {
  if (
    task.title &&
    task.title.trim()
  ) {
    return task.title;
  }

  return ({
    ISSUE_CLIENT_INVOICE:
      'Выставить счёт',
    CORRECT_CLIENT_INVOICE:
      'Исправить счёт',
    SUPPLIER_PAYMENT:
      'Оплатить поставщику',
    POWER_OF_ATTORNEY:
      'Сделать доверенность',
    ETRN:
      'Создать ЭТРН',
    REALIZATION:
      'Сделать реализацию',
  } as Record<string, string>)[
    task.type || ''
  ] || task.type || 'Задача';
}

function taskState(
  task: LooseTask,
) {
  if (task.urgent) {
    return {
      label: 'Срочно',
      tone: 'urgent',
    };
  }

  return ({
    NEW: {
      label: 'Новая',
      tone: 'new',
    },
    IN_PROGRESS: {
      label: 'В работе',
      tone: 'work',
    },
    NEED_DATA: {
      label: 'Исправить',
      tone: 'fix',
    },
  } as Record<
    string,
    {
      label: string;
      tone: string;
    }
  >)[task.status || ''] || {
    label:
      task.status || 'Активна',
    tone: 'new',
  };
}

function dealState(
  deal: Deal,
  tasks: LooseTask[],
) {
  if (
    tasks.some(
      (task) =>
        task.status === 'NEED_DATA'
    )
  ) {
    return {
      label: 'Нужно исправить',
      tone: 'fix',
    };
  }

  if (deal.status === 'CLOSED') {
    return {
      label: 'Закрыта',
      tone: 'closed',
    };
  }

  const paymentStatus =
    String(
      (deal as any).paymentStatus ||
      ''
    );

  if (
    paymentStatus === 'PAID'
  ) {
    return {
      label: 'Оплачен',
      tone: 'done',
    };
  }

  if (
    paymentStatus === 'WAITING'
  ) {
    return {
      label: 'Ожидаем оплату',
      tone: 'wait',
    };
  }

  if (
    paymentStatus === 'ADVANCE'
  ) {
    return {
      label: 'Аванс',
      tone: 'work',
    };
  }

  if (
    paymentStatus === 'DEFERRED'
  ) {
    return {
      label: 'Отсрочка',
      tone: 'closed',
    };
  }

  return {
    label: 'В работе',
    tone: 'work',
  };
}

// PART_V064_O12_V4_INVOICE_ORG_LABEL
function invoiceSellerLabel(
  sellerType?: string,
) {
  if (sellerType === 'ST') {
    return 'СТ';
  }

  if (sellerType === 'IP') {
    return 'ИП';
  }

  return 'МСМ';
}
// END_PART_V064_O12_V4_INVOICE_ORG_LABEL


function dealInvoice(
  deal: Deal,
) {
  const invoices =
    Array.isArray(
      (deal as any).invoices
    )
      ? (
          (deal as any)
            .invoices as LooseInvoice[]
        )
      : [];

  return (
    invoices.find(
      (invoice) =>
        invoice.isCurrent
    ) ||
    invoices[0] ||
    null
  );
}

function activeTasks(
  deal: Deal,
) {
  const tasks =
    Array.isArray(
      (deal as any).tasks
    )
      ? (
          (deal as any)
            .tasks as LooseTask[]
        )
      : [];

  return tasks.filter(
    (task) =>
      ![
        'DONE',
        'CANCELLED',
      ].includes(
        String(task.status || '')
      )
  );
}

function DealTaskRow({
  task,
}: {
  task: LooseTask;
}) {
  const state =
    taskState(task);

  return (
    <a
      className={
        'boTaskRow boTask-' +
        state.tone
      }
      href={
        '#tasks/' +
        encodeURIComponent(
          task.id,
        )
      }
      onClick={(event) =>
        event.stopPropagation()
      }
    >
      <span className="boTaskBar" />

      <span className="boTaskText">
        <strong>
          {taskLabel(task)}
        </strong>

        <small>
          {
            task.status ===
              'NEED_DATA'
              ? 'Возвращено менеджеру'
              : 'Активная задача'
          }
        </small>
      </span>

      <span
        className={
          'boTaskBadge boTaskBadge-' +
          state.tone
        }
      >
        {state.label}
      </span>
    </a>
  );
}

export function BlockOfficeHome({
  deals,
  onNew,
  onOpen,
}: {
  deals: Deal[];
  onNew: () => void;
  onOpen:
    (id: string) => void;
}) {
  const [
    mode,
    setMode,
  ] = useState<DealViewMode>(
    () =>
      localStorage.getItem(
        'msm.deals.view.v063',
      ) === 'expanded'
        ? 'expanded'
        : 'cards',
  );

  const [
    query,
    setQuery,
  ] = useState('');

  function changeMode(
    next:
      DealViewMode,
  ) {
    setMode(next);

    localStorage.setItem(
      'msm.deals.view.v063',
      next,
    );
  }

  const filteredDeals =
    useMemo(
      () => {
        const needle =
          query
            .trim()
            .toLowerCase();

        if (!needle) {
          return deals;
        }

        return deals.filter(
          (deal) => {
            const invoice =
              dealInvoice(deal);

            const tasks =
              activeTasks(deal);

            const haystack = [
              deal.internalNumber,
              deal.clientName,
              invoice?.number,
              invoice
                ?.invoiceNumber,
              deal.managerComment,
              ...tasks.map(
                taskLabel,
              ),
            ]
              .filter(Boolean)
              .join(' ')
              .toLowerCase();

            return haystack.includes(
              needle,
            );
          },
        );
      },
      [deals, query],
    );

  return (
    <section className="boDealsHome">
      <div className="boToolbar">
        <label className="boSearch">
          <span>⌕</span>

          <input
            id="bo-deal-search"
            value={query}
            onChange={(event) =>
              setQuery(
                event.target.value,
              )
            }
            placeholder="Поиск по сделке, счёту, клиенту, задаче..."
          />
        </label>

        <div className="boToolbarActions">
          <div
            className="boViewToggle"
            aria-label="Вид списка сделок"
          >
            <button
              type="button"
              className={
                mode === 'cards'
                  ? 'active'
                  : ''
              }
              title="Карточки"
              onClick={() =>
                changeMode(
                  'cards',
                )
              }
            >
              ▦
            </button>

            <button
              type="button"
              className={
                mode ===
                'expanded'
                  ? 'active'
                  : ''
              }
              title="Развёрнутый список"
              onClick={() =>
                changeMode(
                  'expanded',
                )
              }
            >
              ≡
            </button>
          </div>

          <button
            type="button"
            className="boCreateDeal"
            onClick={onNew}
          >
            + Новая сделка
          </button>
        </div>
      </div>

      {filteredDeals.length === 0 ? (
        <div className="boEmpty">
          Сделок не найдено.
        </div>
      ) : mode === 'cards' ? (
        <div className="boDealGrid">
          {filteredDeals.map(
            (deal) => {
              const invoice =
                dealInvoice(deal);

              const tasks =
                activeTasks(deal);

              const state =
                dealState(
                  deal,
                  tasks,
                );

              return (
                <article
                  key={deal.id}
                  className={
                    'boDealCard boTone-' +
                    state.tone
                  }
                  onClick={() =>
                    onOpen(deal.id)
                  }
                >
                  <div className="boDealTop">
                    <div>
                      <strong className="boInternalNumber">
                        №{
                          deal
                            .internalNumber
                        }
                      </strong>

                      <span className="boInvoiceNumber">
                        {
                          invoice
                            ? invoiceSellerLabel(
                                invoice.sellerType ||
                                deal.sellerType
                              ) +
                              '-' +
                              (
                                invoice.number ||
                                invoice.invoiceNumber ||
                                '—'
                              )
                            : 'Счёт ещё не создан'
                        }
                      </span>
                    </div>

                    <strong className="boAmount">
                      {money(
                        invoice?.amount,
                      )}
                    </strong>
                  </div>

                  <div className="boClientName">
                    {
                      deal.clientName ||
                      'Клиент не указан'
                    }
                  </div>

                  <div className="boStateRow">
                    <span
                      className={
                        'boStatus boStatus-' +
                        state.tone
                      }
                    >
                      <i />
                      {
                        state.label
                      }
                    </span>

                    <span className="boDealDate">
                      {shortDate(
                        invoice
                          ?.invoiceDate ||
                        invoice
                          ?.createdAt ||
                        deal.createdAt,
                      )}
                    </span>
                  </div>

                  {deal.managerComment && (
                    <div className="boManagerNote">
                      <span>
                        Мой комментарий
                      </span>

                      <strong>
                        {
                          deal.managerComment
                        }
                      </strong>
                    </div>
                  )}

                  {tasks.length > 0 && (
                    <div className="boTasksBlock">
                      <div className="boTasksTitle">
                        {
                          tasks.length === 1
                            ? 'АКТИВНАЯ ЗАДАЧА'
                            : `АКТИВНЫЕ ЗАДАЧИ · ${tasks.length}`
                        }
                      </div>

                      <div className="boTaskStack">
                        {tasks.map(
                          (task) => (
                            <DealTaskRow
                              key={
                                task.id
                              }
                              task={
                                task
                              }
                            />
                          ),
                        )}
                      </div>
                    </div>
                  )}
                </article>
              );
            },
          )}
        </div>
      ) : (
        <div className="boExpanded">
          <div className="boExpandedHead">
            <span>
              Внутр. №
            </span>
            <span>
              Счёт
            </span>
            <span>
              Сумма
            </span>
            <span>
              Статус
            </span>
            <span>
              Задачи
            </span>
            <span>
              Комментарий
            </span>
          </div>

          {filteredDeals.map(
            (deal) => {
              const invoice =
                dealInvoice(deal);

              const tasks =
                activeTasks(deal);

              const state =
                dealState(
                  deal,
                  tasks,
                );

              return (
                <div
                  key={deal.id}
                  className="boExpandedRow"
                  onClick={() =>
                    onOpen(deal.id)
                  }
                >
                  <strong>
                    №{
                      deal
                        .internalNumber
                    }
                  </strong>

                  <span>
                    {
                      invoice
                        ? invoiceSellerLabel(
                            invoice.sellerType ||
                            deal.sellerType
                          ) +
                          '-' +
                          (
                            invoice.number ||
                            invoice.invoiceNumber ||
                            '—'
                          )
                        : '—'
                    }
                  </span>

                  <strong className="boExpandedAmount">
                    {money(
                      invoice?.amount,
                    )}
                  </strong>

                  <span
                    className={
                      'boStatus boStatus-' +
                      state.tone
                    }
                  >
                    <i />
                    {
                      state.label
                    }
                  </span>

                  <div className="boExpandedTasks">
                    {
                      tasks.length
                        ? tasks.map(
                            (task) => (
                              <a
                                key={
                                  task.id
                                }
                                href={
                                  '#tasks/' +
                                  encodeURIComponent(
                                    task.id,
                                  )
                                }
                                onClick={(
                                  event,
                                ) =>
                                  event
                                    .stopPropagation()
                                }
                              >
                                {
                                  taskLabel(
                                    task,
                                  )
                                }
                              </a>
                            ),
                          )
                        : (
                          <span className="boMuted">
                            —
                          </span>
                        )
                    }
                  </div>

                  <span className="boExpandedComment">
                    {
                      deal.managerComment ||
                      '—'
                    }
                  </span>
                </div>
              );
            },
          )}
        </div>
      )}
    </section>
  );
}
