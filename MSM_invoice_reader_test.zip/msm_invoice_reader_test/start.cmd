@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Требуется Node.js. Он уже установлен на компьютере с проектом МСМ.
  pause
  exit /b 1
)
if not exist "node_modules\pdfjs-dist" (
  echo Первая установка библиотек PDF/Excel/Word...
  call npm install --no-audit --no-fund
  if errorlevel 1 (
    echo Не удалось установить зависимости. Проверьте подключение к Интернету.
    pause
    exit /b 1
  )
)
start "" "http://127.0.0.1:3471"
node server.cjs
if errorlevel 1 pause
