'use strict';

const path = require('node:path');

function cleanSpaces(s) {
  return String(s ?? '').replace(/\u00a0|\u202f/g, ' ').replace(/\s+/g, ' ').trim();
}

function extractInvoiceNumber(filename) {
  const stem = path.basename(String(filename || '')).replace(/\.(?:pdf|xlsx|docx|csv|txt)$/i, '').replace(/\u00a0/g, ' ');
  const patterns = [
    /(?:№|#|N\s*[º°])\s*([А-ЯЁA-Z0-9]{1,16}(?:[-_/][А-ЯЁA-Z0-9]{1,16}){0,5})(?=$|[^А-ЯЁA-Z0-9/\-_])/iu,
    /(?:сч[её]т(?:[ _-]+на[ _-]+оплату)?|invoice|inv)[\s_-]+(?:номер[\s_-]+)?([А-ЯЁA-Z]{0,8}[-_]?[0-9]{1,16}(?:[-_][А-ЯЁA-Z0-9]{1,16}){0,4})(?=$|[^А-ЯЁA-Z0-9/\-_])/iu,
    /(?:сч[её]т(?:[ _-]+на[ _-]+оплату)?|invoice|inv)[\s_-]+([0-9]{2,16})(?=$|[^0-9])/iu
  ];
  for (const re of patterns) {
    const hit = re.exec(stem);
    if (hit) return { value: hit[1].replace(/(?:[-_]от[-_]\d.*|[-_]от$)/iu, '').replace(/_+$/g, ''), source: 'Имя файла', confidence: 'high' };
  }
  return { value: '', source: 'Номер не распознан в имени файла', confidence: 'none' };
}

// Require a money-like number, rather than selecting arbitrary dates or quantities.
const MONEY_RE = /(?:\d{1,3}(?:[ \u00a0\u202f]\d{3})+|\d{1,11})(?:[,.]\d{2})?(?=\s*(?:руб\.?|рубл[еяй]|₽|р\.|р\b|$|[,;|)]))/giu;
const STRICT_DECIMAL_RE = /(?:\d{1,3}(?:[ \u00a0\u202f]\d{3})+|\d{1,11})[,.]\d{2}(?!\d)/g;

function parseRubNumber(raw) {
  const text = String(raw || '').replace(/[\u00a0\u202f\s]/g, '').replace(',', '.');
  if (!/^\d{1,11}(?:\.\d{2})?$/.test(text)) return null;
  const value = Number(text);
  return Number.isFinite(value) && value >= 0 ? Math.round(value * 100) / 100 : null;
}

function collectAmounts(part) {
  const candidates = [];
  const push = (match, offset = 0) => {
    const text = match[0];
    const value = parseRubNumber(text);
    if (value === null) return;
    // Prevent detecting a date as money, e.g., 01.10.2026
    const after = part.slice(offset + text.length).trimStart();
    if (/^\.\d{2,4}\b/.test(after)) return;
    if (/^%/.test(after)) return;
    candidates.push({value, raw: cleanSpaces(text), offset});
  };
  for (const m of part.matchAll(STRICT_DECIMAL_RE)) push(m, m.index);
  if (candidates.length) return candidates;
  // Integer amounts are only allowed when explicitly accompanied by monetary units.
  const rubRe = /(?:\d{1,3}(?:[ \u00a0\u202f]\d{3})+|\d{1,11})(?=\s*(?:руб\.?|рубл[еяй]|₽|р\.))(?!\d)/giu;
  for (const m of part.matchAll(rubRe)) push(m, m.index);
  return candidates;
}

const LABELS = [
  { regex: /всего\s*к\s*оплате|к\s*оплате\s*всего|итого\s*к\s*оплате|сумма\s*к\s*оплате/iu, weight: 130, name: 'К оплате' },
  { regex: /всего\s+наименований.{0,75}?на\s+сумму|всего\s+на\s+сумму/iu, weight: 115, name: 'Всего на сумму' },
  { regex: /общая\s+сумма|сумма\s+сч[её]та|стоимость\s+всего/iu, weight: 100, name: 'Общая сумма' },
  { regex: /итого|всего/iu, weight: 82, name: 'Итого' },
];

function extractTotal(lines) {
  const matches = [];
  for (let i = 0; i < lines.length; i++) {
    const row = lines[i];
    const line = cleanSpaces(typeof row === 'string' ? row : row.text);
    if (!line) continue;
    for (const label of LABELS) {
      const lm = label.regex.exec(line);
      if (!lm) continue;
      const negative = /без\s+ндс|ндс\s*\d|налог|скидк|предоплат|аванс|оплачен|долг|оплачено/iu.test(line);
      // Extract AFTER the matched label to avoid picking the number of product lines.
      const tail = line.slice(lm.index + lm[0].length);
      // Ignore a VAT breakdown that follows the actual payable amount on the same line.
      const beforeTax = tail.split(/(?:в\s+том\s+числе\s+|включая\s+)?НДС/iu)[0];
      let amounts = collectAmounts(beforeTax);
      // Numeric Excel cells may contain an integer total without ",00" or a ruble suffix.
      if (!amounts.length && label.weight >= 82) {
        const bare = /(?:^|[|:=]\s*)(\d{2,11})(?![\d.,])/gu;
        amounts = [...beforeTax.matchAll(bare)].map(m=>({value:Number(m[1]),raw:m[1],offset:m.index}));
      }
      let chosen = amounts.at(-1);
      let usedRow = row;
      let currentLine = line;
      if (!chosen && i + 1 < lines.length) {
        const next = lines[i + 1];
        const nextLine = cleanSpaces(typeof next === 'string' ? next : next.text);
        if (nextLine.length < 65 && !/(?:ндс|итого|всего|скидк|наименован|цена|сумма|счет)/iu.test(nextLine)) {
          const nextAmounts = collectAmounts(nextLine);
          chosen = nextAmounts.at(-1);
          if (chosen) { usedRow = next; currentLine = `${line} / ${nextLine}`; }
        }
      }
      if (!chosen) continue;
      let score = label.weight - (negative ? 85 : 0);
      if (/с\s+ндс|включая\s+ндс/iu.test(line)) score += 4;
      matches.push({value: chosen.value, raw: chosen.raw, score, label: label.name, evidence: currentLine.slice(0, 250), source: (typeof usedRow === 'string' ? '' : usedRow.source) || 'Документ'});
      break;
    }
  }
  matches.sort((a,b)=> b.score - a.score);
  if (!matches.length) return {value:null, confidence:'none', evidence:'', source:'', variants:[], note:'Строка с итоговой суммой не найдена. Введите сумму вручную.'};
  const best = matches[0];
  const conflicts = matches.filter(x=> x.score>=best.score - 9 && x.value !== best.value);
  return {
    value:best.value,
    confidence:conflicts.length || best.score < 100 ? 'review' : 'high',
    evidence:best.evidence,
    source:best.source,
    variants: [...new Set(matches.slice(0, 8).map(x=>x.value))],
    note: conflicts.length ? 'В документе есть несколько разных итоговых сумм с одинаковым приоритетом — проверьте значение.' : (best.score < 100 ? 'Найдена строка «Итого»/«Всего», но итог нужно проверить.' : 'Найдена строка с итоговой суммой. Проверьте перед сохранением.')
  };
}

async function parsePdf(bytes) {
  const {getDocument} = await import('pdfjs-dist/legacy/build/pdf.mjs');
  const doc = await getDocument({data:new Uint8Array(bytes),useSystemFonts:true,disableFontFace:true}).promise;
  const all=[];
  const limit = Math.min(doc.numPages, 25);
  for(let p=1;p<=limit;p++) {
    const page = await doc.getPage(p);
    const c = await page.getTextContent();
    const rows = [];
    for(const item of c.items) {
      if (!item.str?.trim()) continue;
      const y = item.transform?.[5] || 0;
      const x = item.transform?.[4] || 0;
      let row = rows.find(r => Math.abs(r.y - y) < 2);
      if (!row) {row={y, parts:[]};rows.push(row);}
      row.parts.push({x,txt:item.str});
    }
    rows.sort((a,b)=>b.y-a.y);
    for(const row of rows) {
      const line = row.parts.sort((a,b)=>a.x-b.x).map(v=>v.txt).join(' ');
      all.push({text:line,source:`PDF, стр. ${p}`});
    }
    page.cleanup();
  }
  await doc.destroy();
  return {lines:all, note:doc.numPages>limit?`Обработаны первые ${limit} страниц из ${doc.numPages}.`:''};
}
async function parseXlsx(bytes) {
  const ExcelJS = require('exceljs');
  const book = new ExcelJS.Workbook();
  await book.xlsx.load(bytes);
  const lines=[];
  for(const sheet of book.worksheets.slice(0,15)) {
    sheet.eachRow({includeEmpty:false},(row,n)=>{
      if(n>3000) return;
      const words=[];
      row.eachCell({includeEmpty:false}, cell=>{
        const v = cell.text ?? cell.value;
        if(v!==null && v!==undefined) words.push(String(v));
      });
      if(words.length) lines.push({text:words.join(' | '),source:`Excel, лист «${sheet.name}», строка ${n}`});
    });
  }
  return {lines,note:''};
}
async function parseDocx(bytes) {
  const mammoth = require('mammoth');
  const result = await mammoth.extractRawText({buffer:bytes});
  return {lines:result.value.split(/\r?\n/).map((text,i)=>({text,source:`Word, строка ${i+1}`})),note:result.messages.length?'Word: часть форматирования могла быть пропущена.':''};
}
async function parseText(bytes) {
  let content=bytes.toString('utf8');
  if (content.includes('\ufffd')) content = new TextDecoder('windows-1251').decode(bytes);
  return {lines:content.split(/\r?\n/).map((text,i)=>({text,source:`Текст, строка ${i+1}`})),note:''};
}
async function analyzeInvoice(filename,bytes) {
  const ext=path.extname(filename).toLowerCase();
  const invoiceNumber=extractInvoiceNumber(filename);
  let parsed;
  if(ext==='.pdf') parsed=await parsePdf(bytes);
  else if(ext==='.xlsx') parsed=await parseXlsx(bytes);
  else if(ext==='.docx') parsed=await parseDocx(bytes);
  else if(ext==='.txt'||ext==='.csv') parsed=await parseText(bytes);
  else throw Object.assign(new Error('Поддерживаются PDF, XLSX, DOCX, TXT и CSV. Сканы и изображения потребуют OCR.'),{status:415});
  const chars=parsed.lines.map(v=>v.text).join('').replace(/\s/g,'').length;
  if(chars<15) return {filename,invoiceNumber,total:{value:null,confidence:'none',source:'',evidence:'',note:'Текст не извлечён. Возможно, это скан PDF или изображение. Для таких файлов потребуется OCR.',variants:[]},warning:parsed.note};
  return {filename,invoiceNumber,total:extractTotal(parsed.lines),warning:parsed.note};
}
module.exports={extractInvoiceNumber,parseRubNumber,extractTotal,analyzeInvoice};
