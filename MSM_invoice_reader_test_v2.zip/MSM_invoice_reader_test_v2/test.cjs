const {test} = require('node:test');
const assert = require('node:assert/strict');
const {extractInvoiceNumber,extractTotal,parseRubNumber,analyzeInvoice} = require('./parser.cjs');
for (const [name, expected] of [
  ['Счет на оплату № КА-58327 от 01.10.2026.xlsx','КА-58327'],
  ['Счёт № 1097 от 08 октября 2026 г.pdf','1097'],
  ['Счет №МСМ-00054_от_11.10.2026.pdf','МСМ-00054'],
  ['invoice_4044.pdf','4044'],
  ['Документ_15.10.2026.pdf','']
])test(`Number: ${name}`,()=>assert.equal(extractInvoiceNumber(name).value,expected));

test('Ruble math',()=>{
  assert.equal(parseRubNumber('2 194 074,63'),2194074.63);
  assert.equal(parseRubNumber('175000.00'),175000);
});

test('Final sum prioritized over VAT and subtotal',()=>{
  const r=extractTotal([
    'Товар 2 шт. 120 000,00',
    'Итого без НДС: 100 000,00',
    'В том числе НДС 20% 20 000,00',
    'Всего к оплате: 120 000,00 руб'
  ]);
  assert.equal(r.value,120000);
  assert.equal(r.confidence,'high');
});

test('Common 1C total with item count',()=>{
  const r=extractTotal(['Всего наименований 10, на сумму 2 194 074,63 руб.']);
  assert.equal(r.value,2194074.63);
});

test('Conflicting totals are flagged',()=>{
  const r=extractTotal(['К оплате всего: 155 000,00','Итого к оплате: 165 000,00']);
  assert.equal(r.confidence,'review');
});

test('No guesses from line dates only',()=>{
  const r=extractTotal(['Счёт № 41 от 01.10.2026','Услуги оказаны']);
  assert.equal(r.value,null);
});

test('Text file full flow',async()=>{
  const b=Buffer.from('Счёт на оплату\nВсего к оплате: 90 500,55 руб.');
  const r=await analyzeInvoice('Счёт № 567 от 11.10.2026.txt',b);
  assert.equal(r.invoiceNumber.value,'567');
  assert.equal(r.total.value,90500.55);
});

test('Do not choose VAT breakdown after final amount',()=>{
 const r=extractTotal(['Итого: 135 000,00 руб. В том числе НДС 25 000,00 руб.']);
 assert.equal(r.value,135000);
});
test('Bare integer sum in Excel row',()=>{
 const r=extractTotal(['Итого | 125000']);
 assert.equal(r.value,125000);
});
