@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title MSM - Invoice Reader Test

echo.
echo =========================================
echo    MSM - TEST INVOICE READER (v2)
echo =========================================
echo Current folder: %CD%
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js is not available in PATH.
  echo Try opening a new terminal or reinstall Node.js.
  goto failed
)
where npm >nul 2>nul
if errorlevel 1 (
  echo ERROR: npm is not available in PATH.
  goto failed
)
if not exist "node_modules\pdfjs-dist\package.json" (
  echo First run: installing PDF / Excel / Word libraries...
  echo This may take several minutes. Keep this window open.
  call npm install --no-audit --no-fund
  if errorlevel 1 (
    echo ERROR: npm install failed. Check Internet connection and npm errors above.
    goto failed
  )
)
echo.
echo Starting local server. The browser will open AFTER the server is ready.
echo If the browser does not open, visit http://127.0.0.1:3471
echo Stop: Ctrl+C
set "MSM_OPEN_BROWSER=1"
node server.cjs
set "SERVER_EXIT=%errorlevel%"
echo.
echo Server stopped, exit code: %SERVER_EXIT%
echo If you saw an error, copy it and send it to ChatGPT.
pause
exit /b %SERVER_EXIT%
:failed
echo.
echo Unable to start. Please send the messages above.
pause
exit /b 1
