'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const {analyzeInvoice} = require('./parser.cjs');
const HOST='127.0.0.1';
const PORT=3471;
const MAX_BYTES=20*1024*1024;
const files={'/':'index.html','/app.js':'app.js','/style.css':'style.css'};
const mime={'html':'text/html; charset=utf-8','js':'text/javascript; charset=utf-8','css':'text/css; charset=utf-8'};
const server=http.createServer(async (req,res)=>{
  res.setHeader('Cache-Control','no-store');
  if(req.method==='GET' && files[req.url]) {
    const file=files[req.url];
    const data=fs.readFileSync(path.join(__dirname,file));
    res.writeHead(200,{'Content-Type':mime[file.split('.').pop()]});return res.end(data);
  }
  if(req.method!=='POST'||!req.url.startsWith('/api/read?')){res.writeHead(404);return res.end('Not found');}
  let name;
  try{name=new URL(req.url,`http://${HOST}:${PORT}`).searchParams.get('name')||'';}catch{return responseError(res,400,'Неверное имя файла');}
  if(name.length>300 || !name)return responseError(res,400,'Выберите файл');
  const chunks=[];let size=0;
  try {
    for await(const chunk of req){size+=chunk.length;if(size>MAX_BYTES)throw Object.assign(new Error('Максимальный размер файла — 20 МБ'),{status:413});chunks.push(chunk);}
    if(!size) throw Object.assign(new Error('Файл пустой'),{status:400});
    const result=await analyzeInvoice(name,Buffer.concat(chunks));
    res.writeHead(200,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify(result));
  } catch(err) {console.error('Read error:',err.message);responseError(res,err.status||422,err.message||'Не удалось прочитать файл');}
});
function responseError(res,status,message){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify({error:message}));}
server.listen(PORT,HOST,()=>{
  console.log(`\nТестовая форма МСМ: http://${HOST}:${PORT}\nФайлы обрабатываются только локально, база и проект МСМ не изменяются.\nНажмите Ctrl+C, чтобы остановить сервер.\n`);
  if (process.platform === 'win32' && process.env.MSM_OPEN_BROWSER === '1') {
    require('node:child_process').exec('start "" "http://127.0.0.1:3471"', {windowsHide:true}, error=>{
      if(error) console.log('Браузер не открылся автоматически. Откройте адрес вручную: http://127.0.0.1:3471');
    });
  }
});
server.on('error',error=>{
  if(error.code==='EADDRINUSE') console.error('Порт 3471 уже занят. Возможно, форма уже запущена. Откройте http://127.0.0.1:3471 или закройте старый процесс.');
  else if(error.code==='EACCES') console.error('Нет разрешения слушать порт 3471.');
  else console.error('Не удалось запустить сервер:',error.message);
  process.exitCode=1;
});
