'use strict';
const $ = id => document.getElementById(id);
const dz=$('dropzone'), input=$('fileInput');
let current=null;
function setError(message){$('error').textContent=message;$('error').classList.toggle('hidden',!message);}
function rub(value){return Number(value).toLocaleString('ru-RU',{minimumFractionDigits:2,maximumFractionDigits:2});}
function putResult(result){
  $('resultPanel').classList.remove('hidden');
  $('invoiceNumber').value=result.invoiceNumber.value||'';
  $('invoiceAmount').value= typeof result.total.value==='number' ? rub(result.total.value) : '';
  $('numberStatus').textContent=result.invoiceNumber.value?'Номер определён по имени файла':'Номер не найден в имени файла. Можно ввести вручную.';
  $('numberStatus').className='hint '+(result.invoiceNumber.value?'good':'review');
  $('amountStatus').textContent=typeof result.total.value==='number' ? (result.total.confidence==='high'?'Итог найден в документе — проверьте.':'Сумма требует проверки.'):'Сумма не распознана. Введите вручную.';
  $('amountStatus').className='hint '+(result.total.confidence==='high'?'good':'review');
  const evidence=Boolean(result.total.evidence);
  $('evidenceBlock').classList.toggle('hidden',!evidence);
  $('evidence').textContent=result.total.evidence||'';
  $('source').textContent=result.total.source||'';
  const note=[result.total.note,result.warning].filter(Boolean).join(' ');
  $('infoWarning').textContent=note;
  $('infoWarning').classList.toggle('hidden',!note);
  $('resultPanel').scrollIntoView({behavior:'smooth',block:'start'});
}
async function read(file){
  if(!file)return;
  current=file;
  setError('');$('resultPanel').classList.add('hidden');
  if(file.size>20*1024*1024){setError('Максимальный размер счёта — 20 МБ.');return;}
  $('fileInfo').textContent=`Выбран файл: ${file.name} · ${(file.size/1024).toFixed(0)} КБ`;
  $('fileInfo').classList.remove('hidden');$('progress').classList.remove('hidden');
  try {
    const response=await fetch('/api/read?name='+encodeURIComponent(file.name),{method:'POST',body:file,headers:{'Content-Type':'application/octet-stream'}});
    let result;
    try{result=await response.json();}catch{throw new Error('Не удалось прочитать ответ сервера');}
    if(!response.ok)throw new Error(result.error||'Не удалось обработать файл');
    putResult(result);
  }catch(e){setError(e.message||String(e));}finally{$('progress').classList.add('hidden');}
}
dz.addEventListener('click',()=>input.click());dz.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();input.click();}});
input.addEventListener('change',e=>read(e.target.files?.[0]));
for (const ev of ['dragenter','dragover']) dz.addEventListener(ev,e=>{e.preventDefault();dz.classList.add('dragover');});
for (const ev of ['dragleave','drop']) dz.addEventListener(ev,e=>{e.preventDefault();dz.classList.remove('dragover');});
dz.addEventListener('drop',e=>read(e.dataTransfer?.files?.[0]));
$('copyButton').addEventListener('click',async()=>{
  const nr=$('invoiceNumber').value.trim(),sum=$('invoiceAmount').value.trim();
  if(!nr&&!sum){setError('Нет значений для копирования.');return;}
  const v=`Номер счёта: ${nr||'не указан'}\nСумма счёта: ${sum||'не указана'} руб.`;
  try{await navigator.clipboard.writeText(v);$('copyButton').textContent='Скопировано ✓';setTimeout(()=>$('copyButton').textContent='Скопировать номер и сумму',1500);}catch{setError('Буфер обмена недоступен. Выделите и скопируйте поля вручную.');}
});
$('resetButton').addEventListener('click',()=>{current=null;input.value='';$('resultPanel').classList.add('hidden');$('fileInfo').classList.add('hidden');setError('');window.scrollTo({top:0,behavior:'smooth'});});
